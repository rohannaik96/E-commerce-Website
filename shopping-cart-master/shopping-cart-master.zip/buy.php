<?php
echo "<script type='text/javascript'>\n";
echo "alert('Thank you for buying  :)');\n";
echo "</script>"; 
?>