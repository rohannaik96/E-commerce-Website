<?php
 //create connection
 $connect=mysqli_connect('localhost','root','','shop');

//check connection
 if(mysqli_connect_errno($connect))
 {
	echo 'Failed to connect to database: '.mysqli_connect_error();
}
else
	echo 'Connected Successfully!!'
 ?>	

<html>
<head>
</head>
<body>


<? php
$result=mysqli_query($connect,"select * from novels");
?>

<h1>Employees</h1>
	<table width="500" cellpadding=5celspacing=5 border=1>
	<tr>
	
	<th>Name</th>
	<th>price</th>
	<th>offer</th>
	<th>img</th>
	</tr>
	
	<?php while($row=mysqli_fetch_array($result)):?>
	<tr>
	
	<td><?php echo $row['name'];?></td>
	<td><?php echo $row['price'];?></td>
	<td><?php echo $row['offer'];?></td>
	<td><?php echo $row['img'];?></td>
	</tr>
	<?php endwhile;?> 
	</table>
	
	</body>
	</html>